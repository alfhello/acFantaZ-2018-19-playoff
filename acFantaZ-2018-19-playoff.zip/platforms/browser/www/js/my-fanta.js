myApp.onPageInit('pageRoster', function(page) {
	displayConsole('onPageInit pageRoster', 'AfterLoaded');
	doShowHeaderFooter(true);	
});
