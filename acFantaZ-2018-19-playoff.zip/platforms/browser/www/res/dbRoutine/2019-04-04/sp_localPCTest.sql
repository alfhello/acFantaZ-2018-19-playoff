CREATE DEFINER=`ascdphk1_admin`@`218.253.202.194` PROCEDURE `sp_localPCTest`(in tsh varchar(20))
BEGIN

select tsh as 'trashTalk';

END